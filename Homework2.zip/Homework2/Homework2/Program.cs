﻿using System.Net;
using System.Net.Http;

class CachingExample
{
    static async Task Main()
    {
        using var client = new HttpClient();
        var url = "https://httpbin.org/cache/3600";

        // Перший запит
        var response1 = await client.GetAsync(url);
        var body1 = await response1.Content.ReadAsStringAsync();

        var etag = response1.Headers.ETag?.Tag ?? "не знайдено";
        var lastModified = response1.Content.Headers.LastModified;
        var contentLength1 = body1.Length;

        Console.WriteLine("Перший запит:");
        Console.WriteLine($"  Status:        {response1.StatusCode}");
        Console.WriteLine($"  Content-Length:{contentLength1} символів");
        Console.WriteLine($"  ETag:          {etag}");
        Console.WriteLine($"  Last-Modified: {lastModified}");

        // Другий запит з Conditional Headers
        var request2 = new HttpRequestMessage(HttpMethod.Get, url);

        if (etag != "не знайдено")
            request2.Headers.IfNoneMatch.ParseAdd(etag);

        if (lastModified.HasValue)
            request2.Headers.IfModifiedSince = lastModified;

        var response2 = await client.SendAsync(request2);
        var body2 = await response2.Content.ReadAsStringAsync();

        Console.WriteLine("\nДругий запит (з Conditional Headers):");
        Console.WriteLine($"  Status:        {response2.StatusCode}");
        Console.WriteLine($"  Content-Length:{body2.Length} символів");

        if (response2.StatusCode == HttpStatusCode.NotModified)
            Console.WriteLine("  ✓ Кешування працює! (304 Not Modified)");
        else
            Console.WriteLine("  ✗ Сервер повернув новий контент");
    }
}