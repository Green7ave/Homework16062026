﻿using System.Net;
using System.Net.Http;

class CookieExample
{
    static async Task Main()
    {
        var cookieContainer = new CookieContainer();
        var handler = new HttpClientHandler
        {
            CookieContainer = cookieContainer,
            AllowAutoRedirect = true
        };

        using var client = new HttpClient(handler);

        // Перший запит — встановити cookies
        var response1 = await client.GetAsync(
            "https://httpbin.org/cookies/set?user=student&token=xyz789"
        );
        Console.WriteLine($"Статус першого запиту: {response1.StatusCode}");

        // Вивести збережені cookies
        var cookies = cookieContainer.GetCookies(new Uri("https://httpbin.org"));
        Console.WriteLine($"\nЗбережені cookies ({cookies.Count}):");
        foreach (Cookie cookie in cookies)
        {
            Console.WriteLine($"  {cookie.Name} = {cookie.Value}");
            Console.WriteLine($"    Domain:  {cookie.Domain}");
            Console.WriteLine($"    Path:    {cookie.Path}");
            Console.WriteLine($"    Expires: {(cookie.Expires == DateTime.MinValue ? "session" : cookie.Expires.ToString())}");
        }

        // Другий запит — відправити cookies
        var response2 = await client.GetAsync("https://httpbin.org/cookies");
        var body = await response2.Content.ReadAsStringAsync();
        Console.WriteLine($"\nВідповідь сервера:\n{body}");
    }
}